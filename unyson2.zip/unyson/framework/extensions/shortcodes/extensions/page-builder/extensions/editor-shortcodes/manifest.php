<?php if (!defined('FW')) die('Forbidden');

$manifest = array(
	'display'    => false,
	'standalone' => true
);
