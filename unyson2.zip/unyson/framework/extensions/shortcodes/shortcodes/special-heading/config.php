<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Special Heading', 'fw'),
	'description'   => __('Add a Special Heading', 'fw'),
	'tab'           => __('Content Elements', 'fw'),
);