<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Divider', 'fw'),
	'description'   => __('Add a Divider', 'fw'),
	'tab'           => __('Content Elements', 'fw'),
	'popup_size'    => 'small'
);