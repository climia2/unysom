jQuery(document).ready(function($){
	$( ".fw-accordion" ).accordion({
        heightStyle: "content"
    });
});