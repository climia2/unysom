/**
 * @deprecated from v1.3.9
 * @see background.init.js
 */
jQuery(document).ready(function($) {
	$('.background-video').wallpaper();
});
