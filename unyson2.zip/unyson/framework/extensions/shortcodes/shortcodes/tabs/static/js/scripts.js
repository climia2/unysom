jQuery(document).ready(function ($) {
	$(".fw-tabs-container").tabs();
});
